module.exports = [
"[project]/.next-internal/server/app/(auth)/register/poblador/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28auth%29_register_poblador_page_actions_23e00639.js.map