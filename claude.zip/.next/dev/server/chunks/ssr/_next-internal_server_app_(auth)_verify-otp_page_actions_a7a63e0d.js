module.exports = [
"[project]/.next-internal/server/app/(auth)/verify-otp/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28auth%29_verify-otp_page_actions_a7a63e0d.js.map