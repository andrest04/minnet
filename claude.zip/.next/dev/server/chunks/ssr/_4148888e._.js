module.exports = [
"[project]/components/ui/Button.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
;
const Button = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"])(({ children, variant = 'primary', size = 'md', fullWidth = false, isLoading = false, disabled, className = '', ...props }, ref)=>{
    const baseStyles = 'inline-flex items-center justify-center font-medium rounded-lg transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed';
    const variants = {
        primary: 'bg-primary text-white hover:bg-primary-light focus:ring-primary shadow-sm',
        secondary: 'bg-secondary text-white hover:bg-secondary-light focus:ring-secondary shadow-sm',
        outline: 'border-2 border-primary text-primary hover:bg-primary hover:text-white focus:ring-primary',
        ghost: 'text-primary hover:bg-neutral focus:ring-primary',
        danger: 'bg-error text-white hover:bg-red-600 focus:ring-error shadow-sm'
    };
    const sizes = {
        sm: 'text-sm px-3 py-1.5 gap-1.5',
        md: 'text-base px-4 py-2.5 gap-2',
        lg: 'text-lg px-6 py-3 gap-2.5'
    };
    const widthClass = fullWidth ? 'w-full' : '';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        ref: ref,
        disabled: disabled || isLoading,
        className: `${baseStyles} ${variants[variant]} ${sizes[size]} ${widthClass} ${className}`,
        ...props,
        children: [
            isLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                className: "animate-spin h-4 w-4",
                xmlns: "http://www.w3.org/2000/svg",
                fill: "none",
                viewBox: "0 0 24 24",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                        className: "opacity-25",
                        cx: "12",
                        cy: "12",
                        r: "10",
                        stroke: "currentColor",
                        strokeWidth: "4"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/Button.tsx",
                        lineNumber: 61,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        className: "opacity-75",
                        fill: "currentColor",
                        d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/Button.tsx",
                        lineNumber: 69,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/components/ui/Button.tsx",
                lineNumber: 55,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0)),
            children
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/Button.tsx",
        lineNumber: 48,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
Button.displayName = 'Button';
}),
"[project]/lib/validations.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Validaciones según requerimientos del documento
/**
 * Validación de email según RFC 5322 (simplificada)
 */ __turbopack_context__.s([
    "AGE_RANGES",
    ()=>AGE_RANGES,
    "COMPANY_POSITIONS",
    ()=>COMPANY_POSITIONS,
    "CONSULTATION_FREQUENCIES",
    ()=>CONSULTATION_FREQUENCIES,
    "EDUCATION_LEVELS",
    ()=>EDUCATION_LEVELS,
    "EXPORT_FORMATS",
    ()=>EXPORT_FORMATS,
    "GENERIC_EMAIL_DOMAINS",
    ()=>GENERIC_EMAIL_DOMAINS,
    "KNOWLEDGE_LEVELS",
    ()=>KNOWLEDGE_LEVELS,
    "PARTICIPATION_OPTIONS",
    ()=>PARTICIPATION_OPTIONS,
    "PROFESSIONS",
    ()=>PROFESSIONS,
    "TOPICS_OF_INTEREST",
    ()=>TOPICS_OF_INTEREST,
    "USE_OBJECTIVES",
    ()=>USE_OBJECTIVES,
    "cleanPhone",
    ()=>cleanPhone,
    "formatPhone",
    ()=>formatPhone,
    "generateOTP",
    ()=>generateOTP,
    "getOTPExpiration",
    ()=>getOTPExpiration,
    "identifierType",
    ()=>identifierType,
    "isOTPExpired",
    ()=>isOTPExpired,
    "validateCorporateEmail",
    ()=>validateCorporateEmail,
    "validateEmail",
    ()=>validateEmail,
    "validateOTP",
    ()=>validateOTP,
    "validatePhonePeru",
    ()=>validatePhonePeru
]);
const validateEmail = (email)=>{
    const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
    return emailRegex.test(email);
};
const validatePhonePeru = (phone)=>{
    const phoneRegex = /^9\d{8}$/;
    return phoneRegex.test(phone.replace(/\s/g, ''));
};
const GENERIC_EMAIL_DOMAINS = [
    'gmail.com',
    'hotmail.com',
    'outlook.com',
    'yahoo.com',
    'icloud.com',
    'live.com',
    'msn.com',
    'aol.com',
    'protonmail.com',
    'mail.com'
];
const validateCorporateEmail = (email)=>{
    if (!validateEmail(email)) return false;
    const domain = email.split('@')[1]?.toLowerCase();
    return !GENERIC_EMAIL_DOMAINS.includes(domain);
};
const validateOTP = (code)=>{
    const otpRegex = /^\d{6}$/;
    return otpRegex.test(code);
};
const identifierType = (identifier)=>{
    const cleaned = identifier.trim();
    if (validateEmail(cleaned)) return 'email';
    if (validatePhonePeru(cleaned)) return 'phone';
    return 'invalid';
};
const formatPhone = (phone)=>{
    const cleaned = phone.replace(/\s/g, '');
    if (cleaned.length !== 9) return phone;
    return `${cleaned.slice(0, 3)} ${cleaned.slice(3, 6)} ${cleaned.slice(6)}`;
};
const cleanPhone = (phone)=>{
    return phone.replace(/\s/g, '');
};
const generateOTP = ()=>{
    return Math.floor(100000 + Math.random() * 900000).toString();
};
const getOTPExpiration = (minutes = 5)=>{
    const now = new Date();
    return new Date(now.getTime() + minutes * 60000);
};
const isOTPExpired = (expiresAt)=>{
    const expiration = typeof expiresAt === 'string' ? new Date(expiresAt) : expiresAt;
    return new Date() > expiration;
};
const AGE_RANGES = [
    {
        value: '18-25',
        label: '18-25 años'
    },
    {
        value: '26-35',
        label: '26-35 años'
    },
    {
        value: '36-45',
        label: '36-45 años'
    },
    {
        value: '46-60',
        label: '46-60 años'
    },
    {
        value: '60+',
        label: 'Más de 60 años'
    }
];
const EDUCATION_LEVELS = [
    {
        value: 'primaria',
        label: 'Primaria'
    },
    {
        value: 'secundaria',
        label: 'Secundaria'
    },
    {
        value: 'tecnico',
        label: 'Técnico'
    },
    {
        value: 'superior',
        label: 'Superior'
    }
];
const PROFESSIONS = [
    {
        value: 'agricultor',
        label: 'Agricultor/a'
    },
    {
        value: 'ganadero',
        label: 'Ganadero/a'
    },
    {
        value: 'comerciante',
        label: 'Comerciante'
    },
    {
        value: 'artesano',
        label: 'Artesano/a'
    },
    {
        value: 'profesor',
        label: 'Profesor/a'
    },
    {
        value: 'minero',
        label: 'Minero/a'
    },
    {
        value: 'construccion',
        label: 'Construcción'
    },
    {
        value: 'salud',
        label: 'Salud (enfermero, médico, etc.)'
    },
    {
        value: 'transporte',
        label: 'Transporte'
    },
    {
        value: 'servicios',
        label: 'Servicios (restaurante, hospedaje, etc.)'
    },
    {
        value: 'otro',
        label: 'Otro'
    }
];
const TOPICS_OF_INTEREST = [
    {
        value: 'agua',
        label: 'Agua'
    },
    {
        value: 'empleo',
        label: 'Empleo'
    },
    {
        value: 'medioambiente',
        label: 'Medioambiente'
    },
    {
        value: 'tierra',
        label: 'Tierra'
    },
    {
        value: 'seguridad',
        label: 'Seguridad'
    },
    {
        value: 'otros',
        label: 'Otros'
    }
];
const KNOWLEDGE_LEVELS = [
    {
        value: 'bajo',
        label: 'Bajo'
    },
    {
        value: 'medio',
        label: 'Medio'
    },
    {
        value: 'alto',
        label: 'Alto'
    }
];
const PARTICIPATION_OPTIONS = [
    {
        value: 'asambleas',
        label: 'Asambleas'
    },
    {
        value: 'capacitaciones',
        label: 'Capacitaciones'
    },
    {
        value: 'encuestas',
        label: 'Encuestas'
    },
    {
        value: 'no_participar',
        label: 'No deseo participar'
    }
];
const COMPANY_POSITIONS = [
    {
        value: 'gerente_social',
        label: 'Gerente de Responsabilidad Social'
    },
    {
        value: 'gestion_social',
        label: 'Gestión Social'
    },
    {
        value: 'conflictos',
        label: 'Resolución de Conflictos'
    },
    {
        value: 'analista',
        label: 'Analista'
    },
    {
        value: 'otro',
        label: 'Otro'
    }
];
const USE_OBJECTIVES = [
    {
        value: 'percepciones',
        label: 'Monitoreo de percepciones'
    },
    {
        value: 'estrategias',
        label: 'Estrategias'
    },
    {
        value: 'reportes',
        label: 'Reportes'
    },
    {
        value: 'riesgos',
        label: 'Riesgos'
    }
];
const CONSULTATION_FREQUENCIES = [
    {
        value: 'semanal',
        label: 'Semanal'
    },
    {
        value: 'quincenal',
        label: 'Quincenal'
    },
    {
        value: 'mensual',
        label: 'Mensual'
    }
];
const EXPORT_FORMATS = [
    {
        value: 'pdf',
        label: 'PDF'
    },
    {
        value: 'csv',
        label: 'CSV'
    }
];
}),
"[project]/app/(auth)/verify-otp/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>VerifyOTPPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/Button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$validations$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/validations.ts [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
function VerifyOTPContent() {
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const identifier = searchParams.get('identifier');
    const type = searchParams.get('type');
    const [code, setCode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([
        '',
        '',
        '',
        '',
        '',
        ''
    ]);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isResending, setIsResending] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const inputRefs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])([]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!identifier || !type) {
            router.push('/login');
        }
    }, [
        identifier,
        type,
        router
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        // Auto-focus en el primer input
        inputRefs.current[0]?.focus();
    }, []);
    const handleChange = (index, value)=>{
        // Solo permitir dígitos
        if (value && !/^\d$/.test(value)) return;
        const newCode = [
            ...code
        ];
        newCode[index] = value;
        setCode(newCode);
        setError('');
        // Auto-focus en el siguiente input
        if (value && index < 5) {
            inputRefs.current[index + 1]?.focus();
        }
        // Auto-submit cuando se completen los 6 dígitos
        if (newCode.every((digit)=>digit !== '') && index === 5) {
            handleVerify(newCode.join(''));
        }
    };
    const handleKeyDown = (index, e)=>{
        if (e.key === 'Backspace' && !code[index] && index > 0) {
            inputRefs.current[index - 1]?.focus();
        }
    };
    const handlePaste = (e)=>{
        e.preventDefault();
        const pastedData = e.clipboardData.getData('text').slice(0, 6);
        if (/^\d+$/.test(pastedData)) {
            const newCode = pastedData.split('').concat(Array(6).fill('')).slice(0, 6);
            setCode(newCode);
            setError('');
            // Focus en el último input completado
            const nextEmptyIndex = newCode.findIndex((digit)=>digit === '');
            if (nextEmptyIndex !== -1) {
                inputRefs.current[nextEmptyIndex]?.focus();
            } else {
                handleVerify(newCode.join(''));
            }
        }
    };
    const handleVerify = async (codeToVerify)=>{
        const otpCode = codeToVerify || code.join('');
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$validations$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["validateOTP"])(otpCode)) {
            setError('Por favor, completa los 6 dígitos');
            return;
        }
        setIsLoading(true);
        setError('');
        try {
            const response = await fetch('/api/auth/verify-otp', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    identifier,
                    code: otpCode
                })
            });
            const data = await response.json();
            if (!response.ok) {
                setError(data.error || 'Error al verificar código');
                setIsLoading(false);
                setCode([
                    '',
                    '',
                    '',
                    '',
                    '',
                    ''
                ]);
                inputRefs.current[0]?.focus();
                return;
            }
            // Si el usuario existe, redirigir al dashboard según su tipo
            if (data.user_exists) {
                // Aquí se guardaría la sesión en localStorage o cookies
                localStorage.setItem('user_id', data.user_id);
                localStorage.setItem('user_type', data.user_type);
                // Redirigir según el tipo de usuario
                if (data.user_type === 'admin') {
                    router.push('/admin');
                } else if (data.user_type === 'empresa') {
                    router.push('/empresa');
                } else {
                    router.push('/poblador');
                }
            } else {
                // Si no existe, redirigir al registro
                router.push(`/register?identifier=${encodeURIComponent(identifier)}&type=${type}`);
            }
        } catch (err) {
            console.error('Error al verificar OTP:', err);
            setError('Error de conexión. Por favor, intenta nuevamente.');
            setIsLoading(false);
        }
    };
    const handleResend = async ()=>{
        setIsResending(true);
        setError('');
        try {
            const response = await fetch('/api/auth/send-otp', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    identifier
                })
            });
            const data = await response.json();
            if (!response.ok) {
                setError(data.error || 'Error al reenviar código');
                setIsResending(false);
                return;
            }
            // Limpiar código y mostrar mensaje de éxito
            setCode([
                '',
                '',
                '',
                '',
                '',
                ''
            ]);
            inputRefs.current[0]?.focus();
            alert('Código reenviado correctamente');
        } catch (err) {
            console.error('Error al reenviar OTP:', err);
            setError('Error de conexión. Por favor, intenta nuevamente.');
        } finally{
            setIsResending(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white rounded-2xl shadow-xl p-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>router.back(),
                        className: "flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                className: "w-4 h-4",
                                fill: "none",
                                stroke: "currentColor",
                                viewBox: "0 0 24 24",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeWidth: 2,
                                    d: "M15 19l-7-7 7-7"
                                }, void 0, false, {
                                    fileName: "[project]/app/(auth)/verify-otp/page.tsx",
                                    lineNumber: 181,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/(auth)/verify-otp/page.tsx",
                                lineNumber: 175,
                                columnNumber: 11
                            }, this),
                            "Volver"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(auth)/verify-otp/page.tsx",
                        lineNumber: 171,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-2xl font-bold text-primary mb-2",
                        children: "Verificar código"
                    }, void 0, false, {
                        fileName: "[project]/app/(auth)/verify-otp/page.tsx",
                        lineNumber: 191,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-muted-foreground mb-8",
                        children: [
                            "Ingresa el código de 6 dígitos enviado a",
                            ' ',
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "font-medium text-foreground",
                                children: type === 'email' ? 'tu email' : 'tu teléfono'
                            }, void 0, false, {
                                fileName: "[project]/app/(auth)/verify-otp/page.tsx",
                                lineNumber: 196,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(auth)/verify-otp/page.tsx",
                        lineNumber: 194,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-3 justify-center",
                                onPaste: handlePaste,
                                children: code.map((digit, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        ref: (el)=>{
                                            inputRefs.current[index] = el;
                                        },
                                        type: "text",
                                        inputMode: "numeric",
                                        maxLength: 1,
                                        value: digit,
                                        onChange: (e)=>handleChange(index, e.target.value),
                                        onKeyDown: (e)=>handleKeyDown(index, e),
                                        disabled: isLoading,
                                        className: `w-12 h-14 text-center text-2xl font-bold rounded-lg border-2 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary ${error ? 'border-error' : digit ? 'border-primary bg-primary/5' : 'border-border'} ${isLoading ? 'opacity-60 cursor-not-allowed' : ''}`
                                    }, index, false, {
                                        fileName: "[project]/app/(auth)/verify-otp/page.tsx",
                                        lineNumber: 205,
                                        columnNumber: 15
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/app/(auth)/verify-otp/page.tsx",
                                lineNumber: 203,
                                columnNumber: 11
                            }, this),
                            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm text-error text-center flex items-center justify-center gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-4 h-4",
                                        fill: "currentColor",
                                        viewBox: "0 0 20 20",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            fillRule: "evenodd",
                                            d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z",
                                            clipRule: "evenodd"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(auth)/verify-otp/page.tsx",
                                            lineNumber: 235,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(auth)/verify-otp/page.tsx",
                                        lineNumber: 230,
                                        columnNumber: 15
                                    }, this),
                                    error
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(auth)/verify-otp/page.tsx",
                                lineNumber: 229,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                                variant: "primary",
                                size: "lg",
                                fullWidth: true,
                                onClick: ()=>handleVerify(),
                                isLoading: isLoading,
                                disabled: code.some((digit)=>digit === ''),
                                children: isLoading ? 'Verificando...' : 'Verificar código'
                            }, void 0, false, {
                                fileName: "[project]/app/(auth)/verify-otp/page.tsx",
                                lineNumber: 245,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-center",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleResend,
                                    disabled: isResending,
                                    className: "text-sm text-primary font-medium hover:underline disabled:opacity-50 disabled:cursor-not-allowed",
                                    children: isResending ? 'Reenviando...' : '¿No recibiste el código? Reenviar'
                                }, void 0, false, {
                                    fileName: "[project]/app/(auth)/verify-otp/page.tsx",
                                    lineNumber: 257,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/(auth)/verify-otp/page.tsx",
                                lineNumber: 256,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(auth)/verify-otp/page.tsx",
                        lineNumber: 201,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(auth)/verify-otp/page.tsx",
                lineNumber: 169,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-6 p-4 bg-info/10 rounded-lg border border-info/20",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-sm text-info text-center",
                    children: "💡 En modo desarrollo, el código OTP se muestra en la consola del servidor"
                }, void 0, false, {
                    fileName: "[project]/app/(auth)/verify-otp/page.tsx",
                    lineNumber: 270,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/(auth)/verify-otp/page.tsx",
                lineNumber: 269,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(auth)/verify-otp/page.tsx",
        lineNumber: 168,
        columnNumber: 5
    }, this);
}
function VerifyOTPPage() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Suspense"], {
        fallback: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: "Cargando..."
        }, void 0, false, {
            fileName: "[project]/app/(auth)/verify-otp/page.tsx",
            lineNumber: 280,
            columnNumber: 25
        }, void 0),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(VerifyOTPContent, {}, void 0, false, {
            fileName: "[project]/app/(auth)/verify-otp/page.tsx",
            lineNumber: 281,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/(auth)/verify-otp/page.tsx",
        lineNumber: 280,
        columnNumber: 5
    }, this);
}
}),
"[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-ssr] (ecmascript)").vendored['react-ssr'].ReactJsxDevRuntime; //# sourceMappingURL=react-jsx-dev-runtime.js.map
}),
];

//# sourceMappingURL=_4148888e._.js.map