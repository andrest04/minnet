module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/punycode [external] (punycode, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("punycode", () => require("punycode"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[project]/utils/supabase/server.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createClient",
    ()=>createClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/ssr/dist/module/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createServerClient$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@supabase/ssr/dist/module/createServerClient.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$headers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/headers.js [app-route] (ecmascript)");
;
;
async function createClient() {
    const cookieStore = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$headers$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["cookies"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createServerClient$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createServerClient"])(("TURBOPACK compile-time value", "https://vmnsikonuryjnxgppkxk.supabase.co"), ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZtbnNpa29udXJ5am54Z3Bwa3hrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE1MzMwNzgsImV4cCI6MjA3NzEwOTA3OH0.VoyZDFUiN4ScQ-u9YZijrC9ybu2YC3LV9Grveml834A"), {
        cookies: {
            getAll () {
                return cookieStore.getAll();
            },
            setAll (cookiesToSet) {
                try {
                    cookiesToSet.forEach(({ name, value, options })=>cookieStore.set(name, value, options));
                } catch  {
                // Handled in middleware
                }
            }
        }
    });
}
}),
"[project]/lib/validations.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Validaciones según requerimientos del documento
/**
 * Validación de email según RFC 5322 (simplificada)
 */ __turbopack_context__.s([
    "AGE_RANGES",
    ()=>AGE_RANGES,
    "COMPANY_POSITIONS",
    ()=>COMPANY_POSITIONS,
    "CONSULTATION_FREQUENCIES",
    ()=>CONSULTATION_FREQUENCIES,
    "EDUCATION_LEVELS",
    ()=>EDUCATION_LEVELS,
    "EXPORT_FORMATS",
    ()=>EXPORT_FORMATS,
    "GENERIC_EMAIL_DOMAINS",
    ()=>GENERIC_EMAIL_DOMAINS,
    "KNOWLEDGE_LEVELS",
    ()=>KNOWLEDGE_LEVELS,
    "PARTICIPATION_OPTIONS",
    ()=>PARTICIPATION_OPTIONS,
    "PROFESSIONS",
    ()=>PROFESSIONS,
    "TOPICS_OF_INTEREST",
    ()=>TOPICS_OF_INTEREST,
    "USE_OBJECTIVES",
    ()=>USE_OBJECTIVES,
    "cleanPhone",
    ()=>cleanPhone,
    "formatPhone",
    ()=>formatPhone,
    "generateOTP",
    ()=>generateOTP,
    "getOTPExpiration",
    ()=>getOTPExpiration,
    "identifierType",
    ()=>identifierType,
    "isOTPExpired",
    ()=>isOTPExpired,
    "validateCorporateEmail",
    ()=>validateCorporateEmail,
    "validateEmail",
    ()=>validateEmail,
    "validateOTP",
    ()=>validateOTP,
    "validatePhonePeru",
    ()=>validatePhonePeru
]);
const validateEmail = (email)=>{
    const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
    return emailRegex.test(email);
};
const validatePhonePeru = (phone)=>{
    const phoneRegex = /^9\d{8}$/;
    return phoneRegex.test(phone.replace(/\s/g, ''));
};
const GENERIC_EMAIL_DOMAINS = [
    'gmail.com',
    'hotmail.com',
    'outlook.com',
    'yahoo.com',
    'icloud.com',
    'live.com',
    'msn.com',
    'aol.com',
    'protonmail.com',
    'mail.com'
];
const validateCorporateEmail = (email)=>{
    if (!validateEmail(email)) return false;
    const domain = email.split('@')[1]?.toLowerCase();
    return !GENERIC_EMAIL_DOMAINS.includes(domain);
};
const validateOTP = (code)=>{
    const otpRegex = /^\d{6}$/;
    return otpRegex.test(code);
};
const identifierType = (identifier)=>{
    const cleaned = identifier.trim();
    if (validateEmail(cleaned)) return 'email';
    if (validatePhonePeru(cleaned)) return 'phone';
    return 'invalid';
};
const formatPhone = (phone)=>{
    const cleaned = phone.replace(/\s/g, '');
    if (cleaned.length !== 9) return phone;
    return `${cleaned.slice(0, 3)} ${cleaned.slice(3, 6)} ${cleaned.slice(6)}`;
};
const cleanPhone = (phone)=>{
    return phone.replace(/\s/g, '');
};
const generateOTP = ()=>{
    return Math.floor(100000 + Math.random() * 900000).toString();
};
const getOTPExpiration = (minutes = 5)=>{
    const now = new Date();
    return new Date(now.getTime() + minutes * 60000);
};
const isOTPExpired = (expiresAt)=>{
    const expiration = typeof expiresAt === 'string' ? new Date(expiresAt) : expiresAt;
    return new Date() > expiration;
};
const AGE_RANGES = [
    {
        value: '18-25',
        label: '18-25 años'
    },
    {
        value: '26-35',
        label: '26-35 años'
    },
    {
        value: '36-45',
        label: '36-45 años'
    },
    {
        value: '46-60',
        label: '46-60 años'
    },
    {
        value: '60+',
        label: 'Más de 60 años'
    }
];
const EDUCATION_LEVELS = [
    {
        value: 'primaria',
        label: 'Primaria'
    },
    {
        value: 'secundaria',
        label: 'Secundaria'
    },
    {
        value: 'tecnico',
        label: 'Técnico'
    },
    {
        value: 'superior',
        label: 'Superior'
    }
];
const PROFESSIONS = [
    {
        value: 'agricultor',
        label: 'Agricultor/a'
    },
    {
        value: 'ganadero',
        label: 'Ganadero/a'
    },
    {
        value: 'comerciante',
        label: 'Comerciante'
    },
    {
        value: 'artesano',
        label: 'Artesano/a'
    },
    {
        value: 'profesor',
        label: 'Profesor/a'
    },
    {
        value: 'minero',
        label: 'Minero/a'
    },
    {
        value: 'construccion',
        label: 'Construcción'
    },
    {
        value: 'salud',
        label: 'Salud (enfermero, médico, etc.)'
    },
    {
        value: 'transporte',
        label: 'Transporte'
    },
    {
        value: 'servicios',
        label: 'Servicios (restaurante, hospedaje, etc.)'
    },
    {
        value: 'otro',
        label: 'Otro'
    }
];
const TOPICS_OF_INTEREST = [
    {
        value: 'agua',
        label: 'Agua'
    },
    {
        value: 'empleo',
        label: 'Empleo'
    },
    {
        value: 'medioambiente',
        label: 'Medioambiente'
    },
    {
        value: 'tierra',
        label: 'Tierra'
    },
    {
        value: 'seguridad',
        label: 'Seguridad'
    },
    {
        value: 'otros',
        label: 'Otros'
    }
];
const KNOWLEDGE_LEVELS = [
    {
        value: 'bajo',
        label: 'Bajo'
    },
    {
        value: 'medio',
        label: 'Medio'
    },
    {
        value: 'alto',
        label: 'Alto'
    }
];
const PARTICIPATION_OPTIONS = [
    {
        value: 'asambleas',
        label: 'Asambleas'
    },
    {
        value: 'capacitaciones',
        label: 'Capacitaciones'
    },
    {
        value: 'encuestas',
        label: 'Encuestas'
    },
    {
        value: 'no_participar',
        label: 'No deseo participar'
    }
];
const COMPANY_POSITIONS = [
    {
        value: 'gerente_social',
        label: 'Gerente de Responsabilidad Social'
    },
    {
        value: 'gestion_social',
        label: 'Gestión Social'
    },
    {
        value: 'conflictos',
        label: 'Resolución de Conflictos'
    },
    {
        value: 'analista',
        label: 'Analista'
    },
    {
        value: 'otro',
        label: 'Otro'
    }
];
const USE_OBJECTIVES = [
    {
        value: 'percepciones',
        label: 'Monitoreo de percepciones'
    },
    {
        value: 'estrategias',
        label: 'Estrategias'
    },
    {
        value: 'reportes',
        label: 'Reportes'
    },
    {
        value: 'riesgos',
        label: 'Riesgos'
    }
];
const CONSULTATION_FREQUENCIES = [
    {
        value: 'semanal',
        label: 'Semanal'
    },
    {
        value: 'quincenal',
        label: 'Quincenal'
    },
    {
        value: 'mensual',
        label: 'Mensual'
    }
];
const EXPORT_FORMATS = [
    {
        value: 'pdf',
        label: 'PDF'
    },
    {
        value: 'csv',
        label: 'CSV'
    }
];
}),
"[project]/app/api/auth/verify-otp/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$supabase$2f$server$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/utils/supabase/server.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$validations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/validations.ts [app-route] (ecmascript)");
;
;
;
const MAX_OTP_ATTEMPTS = 3;
async function POST(request) {
    try {
        const { identifier, code } = await request.json();
        if (!identifier || !code) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: 'Se requiere identificador y código'
            }, {
                status: 400
            });
        }
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$validations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["validateOTP"])(code)) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: 'Código OTP debe tener 6 dígitos'
            }, {
                status: 400
            });
        }
        // Normalizar el identificador (igual que en send-otp)
        const normalizedIdentifier = identifier.includes('@') ? identifier.toLowerCase().trim() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$validations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["cleanPhone"])(identifier);
        const supabase = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$supabase$2f$server$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createClient"])();
        // Buscar el OTP más reciente para este identificador que no esté verificado
        const { data: otpRecords, error: selectError } = await supabase.from('otp_codes').select('*').eq('identifier', normalizedIdentifier).eq('verified', false).order('created_at', {
            ascending: false
        }).limit(1);
        if (selectError) {
            console.error('Error al buscar OTP:', selectError);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: 'Error al verificar código'
            }, {
                status: 500
            });
        }
        if (!otpRecords || otpRecords.length === 0) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: 'No se encontró un código de verificación. Por favor, solicita uno nuevo.'
            }, {
                status: 404
            });
        }
        const otpRecord = otpRecords[0];
        // Verificar si el OTP ha expirado
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$validations$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isOTPExpired"])(otpRecord.expires_at)) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: 'El código ha expirado. Por favor, solicita uno nuevo.'
            }, {
                status: 400
            });
        }
        // Verificar número de intentos
        if (otpRecord.attempts >= MAX_OTP_ATTEMPTS) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: 'Has excedido el número de intentos. Por favor, solicita un nuevo código.'
            }, {
                status: 400
            });
        }
        // Verificar si el código es correcto
        if (otpRecord.code !== code) {
            // Incrementar intentos
            await supabase.from('otp_codes').update({
                attempts: otpRecord.attempts + 1
            }).eq('id', otpRecord.id);
            const remainingAttempts = MAX_OTP_ATTEMPTS - (otpRecord.attempts + 1);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: `Código incorrecto. Te quedan ${remainingAttempts} intentos.`
            }, {
                status: 400
            });
        }
        // Código correcto - marcar como verificado
        await supabase.from('otp_codes').update({
            verified: true
        }).eq('id', otpRecord.id);
        // Verificar si el usuario ya existe en la base de datos
        const identifierColumn = identifier.includes('@') ? 'email' : 'phone';
        const { data: existingProfile, error: profileError } = await supabase.from('profiles').select('id, user_type').eq(identifierColumn, normalizedIdentifier).single();
        if (profileError && profileError.code !== 'PGRST116') {
            // PGRST116 = no rows returned
            console.error('Error al buscar perfil:', profileError);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: 'Error al verificar usuario'
            }, {
                status: 500
            });
        }
        // Si el usuario existe, iniciar sesión
        if (existingProfile) {
            // Aquí crearías una sesión real con Supabase Auth
            // Por ahora solo retornamos la información
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: true,
                user_exists: true,
                user_id: existingProfile.id,
                user_type: existingProfile.user_type,
                requires_registration: false,
                message: 'Código verificado correctamente'
            });
        }
        // Si no existe, indicar que debe registrarse
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            user_exists: false,
            requires_registration: true,
            identifier: normalizedIdentifier,
            identifier_type: identifier.includes('@') ? 'email' : 'phone',
            message: 'Código verificado. Por favor, completa tu registro.'
        });
    } catch (error) {
        console.error('Error en verify-otp:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            error: 'Error interno del servidor'
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__2e0f190d._.js.map