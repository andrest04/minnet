(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@supabase_node-fetch_browser_ebbd8575.js",
  "static/chunks/node_modules_330cf17f._.js",
  "static/chunks/_f1921190._.js"
],
    source: "dynamic"
});
