var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[root-of-the-server]__7624faae._.js")
R.c("server/chunks/node_modules_c92946bb._.js")
R.c("server/chunks/[root-of-the-server]__7e32eb65._.js")
R.c("server/chunks/[root-of-the-server]__c97961e4._.js")
R.m(62395)
module.exports=R.m(62395).exports
