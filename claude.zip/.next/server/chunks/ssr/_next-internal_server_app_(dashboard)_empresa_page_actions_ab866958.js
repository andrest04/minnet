module.exports=[46306,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_empresa_page_actions_ab866958.js.map