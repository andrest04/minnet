module.exports=[70323,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_poblador_page_actions_a246b991.js.map