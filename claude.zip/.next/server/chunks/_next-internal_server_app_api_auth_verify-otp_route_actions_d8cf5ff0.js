module.exports=[18727,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_auth_verify-otp_route_actions_d8cf5ff0.js.map