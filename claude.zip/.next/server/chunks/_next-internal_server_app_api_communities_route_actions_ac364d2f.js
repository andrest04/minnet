module.exports=[14480,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_communities_route_actions_ac364d2f.js.map