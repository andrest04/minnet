module.exports=[22337,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_companies_route_actions_373a0230.js.map