var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/communities/route.js")
R.c("server/chunks/[root-of-the-server]__fa383c62._.js")
R.c("server/chunks/node_modules_ae5569c2._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_cff6ae2e._.js")
R.c("server/chunks/[root-of-the-server]__c97961e4._.js")
R.c("server/chunks/_next-internal_server_app_api_communities_route_actions_ac364d2f.js")
R.m(10494)
module.exports=R.m(10494).exports
