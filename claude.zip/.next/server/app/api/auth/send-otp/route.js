var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/send-otp/route.js")
R.c("server/chunks/[root-of-the-server]__7cfe8a7c._.js")
R.c("server/chunks/node_modules_ae5569c2._.js")
R.c("server/chunks/_cff6ae2e._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__c97961e4._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_send-otp_route_actions_91045f40.js")
R.m(95797)
module.exports=R.m(95797).exports
