var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/verify-otp/route.js")
R.c("server/chunks/[root-of-the-server]__dbd35d32._.js")
R.c("server/chunks/node_modules_ae5569c2._.js")
R.c("server/chunks/_cff6ae2e._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__c97961e4._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_verify-otp_route_actions_d8cf5ff0.js")
R.m(76424)
module.exports=R.m(76424).exports
