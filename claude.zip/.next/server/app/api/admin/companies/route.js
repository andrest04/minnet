var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/companies/route.js")
R.c("server/chunks/[root-of-the-server]__466b2a2f._.js")
R.c("server/chunks/node_modules_ae5569c2._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_cff6ae2e._.js")
R.c("server/chunks/[root-of-the-server]__c97961e4._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_companies_route_actions_373a0230.js")
R.m(61145)
module.exports=R.m(61145).exports
