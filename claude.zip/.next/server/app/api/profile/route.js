var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/profile/route.js")
R.c("server/chunks/[root-of-the-server]__86de2d88._.js")
R.c("server/chunks/node_modules_ae5569c2._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_cff6ae2e._.js")
R.c("server/chunks/[root-of-the-server]__c97961e4._.js")
R.c("server/chunks/_next-internal_server_app_api_profile_route_actions_0369ef5c.js")
R.m(9303)
module.exports=R.m(9303).exports
